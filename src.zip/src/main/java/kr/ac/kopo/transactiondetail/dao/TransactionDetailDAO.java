package kr.ac.kopo.transactiondetail.dao;

import kr.ac.kopo.transactiondetail.vo.TransactionDetailVO;

public interface TransactionDetailDAO {
	void insertTransaction(TransactionDetailVO transaction);
}
